# War Room — CoC Upgrade Advisor

A static website version of the War Room Clash of Clans upgrade advisor.

## Files

- `index.html` — the full website. It is self-contained and can be uploaded directly to any static hosting provider.

## How to open locally

Double-click `index.html`, or drag it into a browser.

## How to publish

Use any static host:

### Netlify / Vercel
Upload the whole folder or ZIP file. The entry file is `index.html`.

### GitHub Pages
Create a repository, upload `index.html` to the root, then enable Pages for the main branch.

### Any web host
Upload `index.html` to the public/root folder.

## Notes

This is a client-side-only app. It does not send the pasted Clash of Clans export anywhere; parsing happens in the browser.
